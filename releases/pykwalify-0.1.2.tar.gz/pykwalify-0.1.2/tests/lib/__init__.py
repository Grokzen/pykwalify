# -*- coding: utf-8 -*-

""" pyKwalify validation framework """

__author__ = 'Grokzen <Grokzen@gmail.com>'
